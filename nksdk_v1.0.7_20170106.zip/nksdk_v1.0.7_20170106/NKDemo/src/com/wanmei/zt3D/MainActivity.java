package com.wanmei.zt3D;

import org.json.JSONObject;

import com.nkgame.NKBaseSDK;
import com.nkgame.NKListener;
import com.nkgame.NKPayInfo;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;


public class MainActivity extends Activity {

    private class MyListener implements NKListener {
        @Override
        public void onInit(int errorCode, JSONObject json) {
            Log.d("Game",String.format("init errorCode:%s json:%s ",errorCode ,json.toString()));
//            如果errorCode不为0则通知玩家，然后销毁游戏
        }

        @Override
        public void onLogin(int errorCode, JSONObject json) {
//            errorCode为0表示登录成功，从json中获取uuid和token传给游戏服务器做验证
//            如果errorCode为1则表示用户没有成功登录，需要游戏再次弹出登录界面
                if(errorCode == 1)
                {
                    NKBaseSDK.getInstance().login("Line1","游戏1区");
                }
                Log.d("Game",String.format("login errorCode:%s json:%s ",errorCode ,json.toString()));
        }

        @Override
        public void onLogout(int errorCode, JSONObject json) {
            Log.d("Game",String.format("logout errorCode:%s json:%s ",errorCode ,json.toString()));
//            errorCode只会为0，收到此消息表示玩家主动登出了账号
        }

        @Override
        public void onPay(int errorCode, JSONObject json) {
            Log.d("Game",String.format("pay errorCode:%s json:%s ",errorCode ,json.toString()));
//            errorCode为0表示支付操作完成，具体是否是有效充值要等游戏服务器收到通知为准
//            errorCode为1表示玩家取消了支付
        }

        @Override
        public void onQuit(int errorCode, JSONObject json) {
            Log.d("Game",String.format("quit errorCode:%s json:%s ",errorCode ,json.toString()));
//            errorCode只会为0，收到此消息开始游戏的销毁操作
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        if(this.getResources().getConfiguration().orientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
        {
//            竖屏
//            NKBaseSDK.getInstance().init(this, "NIK-BPBGWJ-0012", "TEST", false,new MyListener());
        	 NKBaseSDK.getInstance().init(this, "NIK-ZT-0009", "TEST", false,new MyListener());
        }
        else
        {
//            横屏
//            NKBaseSDK.getInstance().init(this, "NIK-BPBGWJ-0012", "TEST", true,new MyListener());
            NKBaseSDK.getInstance().init(this, "NIK-ZT-0009", "TEST", true,new MyListener());
        }


        NKBaseSDK.getInstance().onCreate();

        findViewById(getResources().getIdentifier("nkgame_test_btn_login","id",getPackageName())).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NKBaseSDK.getInstance().login("Line1","游戏1区");
            }
        });
        findViewById(getResources().getIdentifier("nkgame_test_btn_pay","id",getPackageName())).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NKPayInfo payInfo = new NKPayInfo();
                payInfo.setAmount(100);
                payInfo.setExchangeRatio(100);
                payInfo.setMoneyName("钻石");
                payInfo.setExtra("extra");
                payInfo.setProductId("12345");
                payInfo.setProductName("648来一发");
                NKBaseSDK.getInstance().pay(payInfo);
            }
        });

        findViewById(getResources().getIdentifier("nkgame_test_btn_usercenter","id",getPackageName())).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NKBaseSDK.getInstance().userCenter();
            }
        });

        findViewById(getResources().getIdentifier("nkgame_test_btn_switch","id",getPackageName())).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NKBaseSDK.getInstance().switchAccount("Line1","游戏1区");
            }
        });
        findViewById(getResources().getIdentifier("nkgame_test_btn_logout","id",getPackageName())).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NKBaseSDK.getInstance().logout();
            }
        });

        findViewById(getResources().getIdentifier("nkgame_test_btn_quit","id",getPackageName())).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!NKBaseSDK.getInstance().hasQuitPanel())
                {
//            sdk没有退出界面,游戏可以弹出自己的退出界面,之后调用quit
                }
                else
                {
//            sdk有退出界面,游戏不要弹出自己的退出确认界面
                }
//                调用SDK的quit方法,等待SDK回调onQuit再进行销毁
                NKBaseSDK.getInstance().quit();
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        NKBaseSDK.getInstance().onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        NKBaseSDK.getInstance().onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        NKBaseSDK.getInstance().onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        NKBaseSDK.getInstance().onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
        NKBaseSDK.getInstance().onStart();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        NKBaseSDK.getInstance().onRestart();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        NKBaseSDK.getInstance().onNewIntent(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        NKBaseSDK.getInstance().onActivityResult(requestCode,resultCode,data);
    }
}
